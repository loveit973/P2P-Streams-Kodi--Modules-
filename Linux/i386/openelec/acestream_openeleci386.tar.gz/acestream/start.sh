#!/bin/sh

export LD_LIBRARY_PATH="/storage/.xbmc/userdata/addon_data/plugin.video.p2p-streams/acestream/openssl-build/ssl/lib"
/storage/.xbmc/userdata/addon_data/plugin.video.p2p-streams/acestream/acestreamengine --client-console --lib-path "/storage/.xbmc/userdata/addon_data/plugin.video.p2p-streams/acestream"
