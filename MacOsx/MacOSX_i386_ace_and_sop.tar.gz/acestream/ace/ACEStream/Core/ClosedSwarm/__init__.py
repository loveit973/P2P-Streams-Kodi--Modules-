#Embedded file name: ACEStream\Core\ClosedSwarm\__init__.pyo
pass
