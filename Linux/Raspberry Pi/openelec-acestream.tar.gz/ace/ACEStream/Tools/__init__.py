#Embedded file name: ACEStream\Tools\__init__.pyo
pass
