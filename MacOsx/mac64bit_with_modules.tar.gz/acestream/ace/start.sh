echo "ola"
python start.py
