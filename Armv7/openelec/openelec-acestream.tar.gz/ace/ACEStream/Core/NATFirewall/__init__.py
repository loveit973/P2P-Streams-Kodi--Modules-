#Embedded file name: ACEStream\Core\NATFirewall\__init__.pyo
pass
