#!/bin/bash
python start.py
