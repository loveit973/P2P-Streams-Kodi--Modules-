#Embedded file name: ACEStream\Core\Merkle\__init__.pyo
pass
