export LD_LIBRARY_PATH=/storage/.xbmc/userdata/addon_data/plugin.video.p2p-streams/acestream/lib
/storage/.xbmc/userdata/addon_data/plugin.video.p2p-streams/acestream/acestreamengine --lib-path /storage/.xbmc/userdata/addon_data/plugin.video.p2p-streams/acestream --client-console $1 $2
