#Embedded file name: ACEStream\Core\CacheDB\__init__.pyo
pass
